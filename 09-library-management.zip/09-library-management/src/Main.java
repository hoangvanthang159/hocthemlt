import logichandle.MenuLogicHandle;

public class Main {

    public static void main(String[] args) {
        MenuLogicHandle menuLogicHandle = new MenuLogicHandle();
        menuLogicHandle.menu();
    }


}